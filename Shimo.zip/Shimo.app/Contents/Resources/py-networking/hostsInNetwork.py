#!/usr/bin/python -B

import sys
import argparse
import subprocess
from netaddr import *

parser = argparse.ArgumentParser(description='Return all host IPs of a network.')
parser.add_argument("network", help="Network")
parser.add_argument('--num', metavar='N', type=int, default=-1, help='Return only the first N host IPs.')
args = parser.parse_args()

# get requested target address
network = IPNetwork(args.network)

hostList = list(network)
if args.num > 0:
    hostList = hostList[0:args.num]

# return our final set of host IPs
if len(hostList) >= 1:
  hostStringlist = ' '.join(str(x) for x in hostList)
  
  print(hostStringlist)